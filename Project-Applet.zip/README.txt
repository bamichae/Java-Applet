This is a Java Applet that calulates a person's federal and state taxes based on profession, income, and other factors. There is an html page included to run the applet on a server. 

Project frameworks by BJ Streller, but primarily implemented by Ben Michaels
